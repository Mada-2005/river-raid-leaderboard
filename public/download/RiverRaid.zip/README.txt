========================================
         RIVER RAID - README
========================================

Welcome to River Raid!

A classic arcade-style shooter where you pilot
a plane through enemy territory!

========================================
  INSTALLATION
========================================

IMPORTANT: If the game doesn't start, you need
to install Visual C++ Redistributable first!

STEP 1: Install Visual C++ Redistributable
-------------------------------------------
Download and install ONE of these (FREE from Microsoft):

RECOMMENDED (for most modern PCs):
https://aka.ms/vs/17/release/vc_redist.x64.exe

OR if that doesn't work, try x86 version:
https://aka.ms/vs/17/release/vc_redist.x86.exe

Install it, restart your computer, then try the game!

STEP 2: Run the Game
--------------------
1. Double-click RiverRaid.exe
2. That's it!

========================================
  SYSTEM REQUIREMENTS
========================================

- Windows 7, 8, 10, or 11 (64-bit or 32-bit)
- Visual C++ Redistributable (link above)
- 4MB free disk space
- Mouse and Keyboard

========================================
  CONTROLS
========================================

W / Up Arrow    - Move Up
S / Down Arrow  - Move Down
A / Left Arrow  - Move Left
D / Right Arrow - Move Right
SPACE           - Fire Bullet

========================================
  HOW TO PLAY
========================================

OBJECTIVE:
- Shoot down enemy helicopters, tanks, and jets
- Avoid crashing into bridges and land
- Collect fuel depots to refill your fuel
- Stay in the river (blue area)
- Survive as long as possible!

SCORING:
Helicopter: 60 points
Tank:       30 points
Jet:        100 points

========================================
  ONLINE LEADERBOARD
========================================

Your scores are automatically uploaded to
the global online leaderboard!

View rankings at:
https://river-raid-leaderboard.onrender.com/leaderboard.html

Compete with players worldwide!

========================================
  TROUBLESHOOTING
========================================

"The code execution cannot proceed because
MSVCP140.dll was not found" or similar:
→ Install Visual C++ Redistributable (link above)
→ Restart your computer
→ Try again

Game won't start / Missing DLL errors:
→ Install Visual C++ Redistributable (see STEP 1)
→ Make sure you downloaded the right version:
  - 64-bit Windows → vc_redist.x64.exe
  - 32-bit Windows → vc_redist.x86.exe
→ Restart computer after installing

Game crashes immediately:
→ Right-click RiverRaid.exe → Properties
  → Compatibility → Run as administrator
→ Try Windows 7 compatibility mode

Still not working?
→ Make sure all files were extracted from the zip
→ Disable antivirus temporarily
→ Try running from a different folder
  (not Downloads - move to Desktop or Documents)

========================================
  TIPS & STRATEGY
========================================

- Watch your fuel! Collect fuel depots
- Jets are fast but worth the most points
- Stay in the center of the river for safety
- Time your shots carefully
- The game gets harder as you level up!

========================================
  ABOUT
========================================

River Raid - C++ Game Project
Built with CMUgraphics Library

Online Leaderboard powered by Node.js
Deployed on Render.com

Enjoy the game and good luck climbing
the leaderboard! 🚀

========================================
  LINKS
========================================

Visual C++ Redistributable (64-bit):
https://aka.ms/vs/17/release/vc_redist.x64.exe

Visual C++ Redistributable (32-bit):
https://aka.ms/vs/17/release/vc_redist.x86.exe

Online Leaderboard:
https://river-raid-leaderboard.onrender.com/leaderboard.html

========================================
