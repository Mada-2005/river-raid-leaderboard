========================================
         RIVER RAID - README
========================================

Welcome to River Raid!

A classic arcade-style shooter where you pilot
a plane through enemy territory, dodging
obstacles and shooting down enemies!

========================================
  INSTALLATION
========================================

1. Extract all files to any folder
2. Double-click RiverRaid.exe to play
3. That's it! No installation required

========================================
  SYSTEM REQUIREMENTS
========================================

- Windows 7, 8, 10, or 11
- 4MB free disk space
- Mouse and Keyboard

========================================
  HOW TO PLAY
========================================

CONTROLS:
---------
W / Up Arrow    - Move Up
S / Down Arrow  - Move Down
A / Left Arrow  - Move Left
D / Right Arrow - Move Right
SPACE           - Fire Bullet

OBJECTIVE:
----------
- Shoot down enemy helicopters, tanks, and jets
- Avoid crashing into bridges and land
- Collect fuel depots to refill your fuel
- Stay in the river (blue area)
- Survive as long as possible!

SCORING:
--------
Helicopter: 60 points
Tank:       30 points
Jet:        100 points

========================================
  ONLINE LEADERBOARD
========================================

Your scores are automatically uploaded to
the global online leaderboard!

View rankings at:
https://river-raid-leaderboard.onrender.com/leaderboard.html

Compete with players worldwide!

========================================
  TIPS & STRATEGY
========================================

- Watch your fuel! Collect fuel depots
- Jets are fast but worth the most points
- Stay in the center of the river for safety
- Time your shots carefully
- The game gets harder as you level up!

========================================
  TROUBLESHOOTING
========================================

Game won't start?
- Make sure you have Windows 7 or newer
- Right-click RiverRaid.exe → Properties
  → Compatibility → Run as administrator

Game crashes?
- Ensure all files were extracted
- Try running in compatibility mode
- Disable antivirus temporarily

Other issues?
- Contact: [your email/contact]

========================================
  ABOUT
========================================

River Raid - C++ Game Project
Built with CMUgraphics Library

Online Leaderboard powered by Node.js
Deployed on Render.com

Enjoy the game and good luck climbing
the leaderboard! 🚀

========================================
